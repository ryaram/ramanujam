from distutils.core import setup

setup(
    name='biostuff',
    version='0.1dev',
    author='John Doe',
    author_email='johndoe@example.com',
    url='example.com',
    packages=['biostuff',],
    license='GPLv3',
    long_description=open('README.txt').read()
)

